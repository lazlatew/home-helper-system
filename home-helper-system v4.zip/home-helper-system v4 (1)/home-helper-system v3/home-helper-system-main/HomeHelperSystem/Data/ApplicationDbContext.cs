using Microsoft.EntityFrameworkCore;
using HomeHelperSystem.Models;

namespace HomeHelperSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        public DbSet<TaskItem> Tasks { get; set; }
    }
}