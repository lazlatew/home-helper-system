using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using HomeHelperSystem.Data;
using HomeHelperSystem.Models;

namespace HomeHelperSystem.Pages.Tasks
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        public IndexModel(ApplicationDbContext db) => _db = db;

        public IList<TaskItem> Tasks { get; set; } = new List<TaskItem>();

        // For chart
        public int PendingCount { get; set; }
        public int DoneCount { get; set; }

        public async Task OnGetAsync()
        {
            Tasks = await _db.Tasks.OrderByDescending(t => t.CreatedAt).ToListAsync();
            PendingCount = await _db.Tasks.CountAsync(t => t.Status == TaskStatus.Pending);
            DoneCount = await _db.Tasks.CountAsync(t => t.Status == TaskStatus.Done);
        }
    }
}