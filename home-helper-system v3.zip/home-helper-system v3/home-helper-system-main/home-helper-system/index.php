<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Образцов Дом</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<header>
<h1>🏠 Система за домашни помощници</h1>
</header>

<div class="container">

<h2>Добре дошли</h2>
<p style="color:#64748b; margin-bottom:28px;">Управлявайте домашните си задачи лесно и бързо.</p>

<div class="dashboard-grid">
<a href="views/register.php" class="dashboard-card">
<span class="icon">📝</span> Регистрация
</a>
<a href="views/login.php" class="dashboard-card">
<span class="icon">🔑</span> Вход
</a>
</div>

</div>

</body>
</html>
