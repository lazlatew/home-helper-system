<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard – Образцов Дом</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<header>
<h1>🏠 Образцов Дом</h1>
</header>

<div class="top-links">
<a href="tasks.php">📋 Всички задачи</a>
<a href="upload.php">📷 Качи снимка</a>
<a href="admin.php">⚙️ Админ панел</a>
</div>

<div class="container">

<h2>Dashboard</h2>

<div class="dashboard-grid">
<a href="create_task.php" class="dashboard-card">
<span class="icon">➕</span> Нова задача
</a>
<a href="locations.php" class="dashboard-card">
<span class="icon">📍</span> Моите локации
</a>
<a href="tasks.php" class="dashboard-card">
<span class="icon">📋</span> Всички задачи
</a>
<a href="upload.php" class="dashboard-card">
<span class="icon">📷</span> Качи снимка
</a>
</div>

</div>

</body>
</html>
