<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Нова задача – Образцов Дом</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<header>
<h1>🏠 Образцов Дом</h1>
</header>

<div class="top-links">
<a href="dashboard.php">← Назад</a>
</div>

<div class="container">

<h2>➕ Нова задача</h2>

<form method="POST" action="../controllers/save_task.php">

<label>Име на задачата</label>
<input type="text" name="name" placeholder="Напр. Почистване на кухня">

<label>Описание</label>
<textarea name="description" placeholder="Опишете задачата подробно..."></textarea>

<label>Краен срок</label>
<input type="date" name="deadline">

<label>Бюджет (лв.)</label>
<input type="number" name="budget" placeholder="0.00">

<label>Категория</label>
<select name="category">
<option>Почистване</option>
<option>Грижа за домашни любимци</option>
<option>Грижа за дете</option>
<option>Грижа за възрастен човек</option>
</select>

<button type="submit">➕ Създай задача</button>

</form>

</div>

</body>
</html>
