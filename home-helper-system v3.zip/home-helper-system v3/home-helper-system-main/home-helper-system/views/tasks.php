 
<?php

include("../config/database.php");

$search="";

if(isset($_GET['search'])){
$search=$_GET['search'];
}

$sql="SELECT * FROM tasks WHERE name LIKE '%$search%'";

$result=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Задачи – Образцов Дом</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<header>
<h1>🏠 Образцов Дом</h1>
</header>

<div class="top-links">
<a href="dashboard.php">← Назад</a>
<a href="create_task.php">➕ Нова задача</a>
</div>

<div class="container">

<h2>📋 Всички задачи</h2>

<form method="GET" style="display:flex; gap:10px; align-items:flex-end;">
<div style="flex:1;">
<label>Търсене</label>
<input type="text" name="search" placeholder="Търси по име на задача..." value="<?php echo htmlspecialchars($search); ?>">
</div>
<button type="submit" style="margin-top:0;">🔍 Търси</button>
</form>

<table>

<tr>
<th>Задача</th>
<th>Описание</th>
<th>Статус</th>
<th>Действие</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>

<td><?php echo htmlspecialchars($row['description']); ?></td>

<td>
<span class="status <?php echo ($row['status']=='Изпълнена' ? 'status-done' : 'status-pending'); ?>">
<?php echo htmlspecialchars($row['status']); ?>
</span>
</td>

<td>
<a href="../controllers/change_status.php?id=<?php echo $row['id']; ?>">✅ Изпълнена</a>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
