<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Вход – Образцов Дом</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<div class="auth-wrapper">
<div class="auth-card">

<div class="auth-logo">🏠</div>

<h2>Вход</h2>
<p>Нямате акаунт? <a href="register.php">Регистрирайте се</a></p>

<form method="POST" action="../controllers/login_user.php">

<label>Потребителско име</label>
<input type="text" name="username" placeholder="Въведете потребителско име" required>

<label>Парола</label>
<input type="password" name="password" placeholder="Въведете парола" required>

<button type="submit" style="width:100%; margin-top:24px;">Вход →</button>

</form>

</div>
</div>

</body>
</html>
