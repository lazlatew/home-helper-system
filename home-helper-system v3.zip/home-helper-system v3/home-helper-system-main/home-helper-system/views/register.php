<!DOCTYPE html>
<html lang="bg">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Регистрация – Образцов Дом</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<div class="auth-wrapper">
<div class="auth-card">

<div class="auth-logo">🏠</div>

<h2>Регистрация</h2>
<p>Вече имате акаунт? <a href="login.php">Влезте тук</a></p>

<form method="POST" action="../controllers/register_user.php">

<label>Потребителско име</label>
<input type="text" name="username" placeholder="Изберете потребителско име" required>

<label>Парола</label>
<input type="password" name="password" placeholder="Изберете парола" required>

<label>Име</label>
<input type="text" name="first_name" placeholder="Вашето име">

<label>Фамилия</label>
<input type="text" name="last_name" placeholder="Вашата фамилия">

<button type="submit" style="width:100%; margin-top:24px;">Регистрация →</button>

</form>

</div>
</div>

</body>
</html>
